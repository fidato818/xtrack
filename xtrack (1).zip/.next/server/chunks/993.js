"use strict";
exports.id = 993;
exports.ids = [993];
exports.modules = {

/***/ 5253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/track-2.7204848c.png","height":97,"width":442,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAQAAADPnVVmAAAALElEQVR42mP4V/2v7N+Ef83/LP8F/4v5V8Lwz/af37+0f5P+1f0L+Bf7rwQAg68WY0bQlRYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 4628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/xtrack.454e704c.png","height":189,"width":233,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAo0lEQVR42mN4bOYZ9NTY/RgQb3li7O73xMTNBsR+Zux25ImpRzoDCDwxctsKlGx7YuS+6omJe/lTY7fyZ0auhx6YeXCAFdy28WN5bOKRB1SwDqgw+KmR2+oHVt5cDMgAKLkcKBkFlFwKNKXmvqU3B5Kk21qgZNdjE/cUoIJtQCsqgFbsvWvpxcLwCOLIs0AFOx4bewQDHekIdOAOID7zxNQjEwBpHEw1nUpVXQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 723:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_StateContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3233);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lib_client__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5018);






const Footer = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_StateContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    const title = context.title[0];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container-fluid p-0 bg-dark",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row m-0 py-2 align-items-center bg-dark bg-gradient",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-6 col-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-white fw-bold text-uppercase",
                                    children: "We’re Always Here To Help"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-lg-3 col-md-6 col-12 text-white text-uppercase",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "fs-5 p-2 rounded-circle",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineMail, {})
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-tiny",
                                        children: [
                                            "Email support :",
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-lowercase",
                                                children: "xtrack.pk@gmail.com"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-lg-3 col-md-6 col-12 text-white text-uppercase",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "fs-5 p-2 rounded-circle",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlinePhone, {})
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-tiny",
                                        children: "Phone support : +923272026242"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-lg-3 col-md-6 col-12 text-white text-uppercase",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "fs-5 p-2 rounded-circle",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineWhatsApp, {})
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-tiny",
                                        children: "WhatsApp support : +923272026242"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col py-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/",
                            children: title ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: (0,_lib_client__WEBPACK_IMPORTED_MODULE_5__/* .urlFor */ .u)(title.logo),
                                alt: "logo",
                                height: "100px"
                            }) : null
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row m-0 px-4 py-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "list-group",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "list-group-item bg-transparent border-0 py-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/docs/about",
                                            className: "text-small text-decoration-none text-white",
                                            children: "About us"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "list-group-item bg-transparent border-0 py-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/docs/terms-and-conditions",
                                            className: "text-small text-decoration-none text-white",
                                            children: "Terms & Conditions"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "list-group-item bg-transparent border-0 py-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/blog",
                                            className: "text-small text-decoration-none text-white",
                                            children: "Blog"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row m-0 px-5 py-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "social-menu",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: "p-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: "https://www.facebook.com/profile.php?id=100088634175544",
                                                target: "blank",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineFacebook, {})
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: "https://www.instagram.com/x_track.pk/",
                                                target: "blank",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineInstagram, {})
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: "https://www.youtube.com/channel/UCY4IDvLi8yxG6MRROmqd65A",
                                                target: "blank",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineYoutube, {})
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: "mailto: xtrack.pk@gmail.com",
                                                target: "blank",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineGooglePlus, {})
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 1891:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var _assets_xtrack_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4628);
/* harmony import */ var _assets_track_2_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5253);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3877);
/* harmony import */ var _lib_client__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5018);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_7__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Carousel = ({ banner  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
            navigation: true,
            centeredSlides: true,
            grabCursor: true,
            modules: [
                swiper__WEBPACK_IMPORTED_MODULE_7__.Navigation,
                swiper__WEBPACK_IMPORTED_MODULE_7__.Autoplay
            ],
            className: "mySwiper d-flex justify-content-center carousel-body",
            slidesPerView: 1,
            autoplay: {
                delay: 3500,
                disableOnInteraction: false
            },
            children: banner?.map((ban)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                    className: "position-relative",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: (0,_lib_client__WEBPACK_IMPORTED_MODULE_8__/* .urlFor */ .u)(ban.image),
                        alt: ban.filename,
                        className: "banner-img"
                    })
                }, ban._id);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Carousel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9111:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Category__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7245);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3877);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Category__WEBPACK_IMPORTED_MODULE_3__, swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__]);
([_Category__WEBPACK_IMPORTED_MODULE_3__, swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Categories = ({ products , categories , slug , setSlug  })=>{
    const proteinSlug = [];
    categories?.map((category)=>{
        if (category.slug == "proteins") {
            proteinSlug.push(category);
        }
    });
    const gainerSlug = [];
    categories?.map((category)=>{
        if (category.slug == "weight-gainers") {
            gainerSlug.push(category);
        }
    });
    const aminosSlug = [];
    categories?.map((category)=>{
        if (category.slug == "bcaa-eaa" || category.slug == "pre-workouts") {
            aminosSlug.push(category);
        }
    });
    const healthSlug = [];
    categories?.map((category)=>{
        if (category.slug == "multivitamins") {
            healthSlug.push(category);
        }
    });
    const accessoriesSlug = [];
    categories?.map((category)=>{
        if (category.slug == "accessories") {
            accessoriesSlug.push(category);
        }
    });
    const proteinP = [];
    const gainerP = [];
    const workoutP = [];
    const healthP = [];
    const accessoriesP = [];
    const brands = [];
    products?.map((product)=>{
        if (product.categories[0]?.slug == "proteins") {
            proteinP.push(product);
        }
    });
    products?.map((product)=>{
        if (product.categories[0]?.slug == "weight-gainers") {
            gainerP.push(product);
        }
    });
    products?.map((product)=>{
        if (product.categories[0]?.slug == "pre-workouts") {
            workoutP.push(product);
        }
    });
    products?.map((product)=>{
        if (product.categories[0]?.slug == "fat-loss-products") {
            healthP.push(product);
        }
    });
    products?.map((product)=>{
        if (product.categories[0]?.slug == "accessories") {
            accessoriesP.push(product);
        }
    });
    categories?.map((cat)=>{
        brands.push(cat);
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container-fluid mb-4 px-2",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center bg-dark my-4 py-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-uppercase text-white fs-6 ",
                        children: "All at one place"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-uppercase fs-2 text-danger fw-bold",
                        children: "Shop By Categories"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container-fluid",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row justify-content-center align-items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
                            navigation: true,
                            grabCursor: true,
                            modules: [
                                swiper__WEBPACK_IMPORTED_MODULE_5__.Navigation
                            ],
                            className: "mySwiper px-3 py-3",
                            breakpoints: {
                                0: {
                                    slidesPerView: 1,
                                    spaceBetween: 30
                                },
                                480: {
                                    slidesPerView: 2,
                                    spaceBetween: 30
                                },
                                768: {
                                    slidesPerView: 3,
                                    spaceBetween: 40
                                },
                                1024: {
                                    slidesPerView: 4,
                                    spaceBetween: 40
                                }
                            },
                            children: brands?.map((cat)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: `/categories/${cat.slug}`,
                                        className: "text-decoration-none text-dark",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "card border-0 rounded-0 m-4",
                                            style: {
                                                width: "15rem"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: cat.assets[0]?.url,
                                                    className: "card-img-top mx-auto my-auto",
                                                    alt: cat.name
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "card-body text-center",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-uppercase text-small fw-bold",
                                                        children: cat.name
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }, cat.id);
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-center bg-dark my-4 py-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-uppercase fs-2 text-danger fw-bold",
                                children: "Popular Categories"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Category__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Proteins",
                            products: proteinP,
                            categories: proteinSlug
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Category__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Weight Gainers",
                            products: gainerP,
                            categories: gainerSlug
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Category__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Pre-workout",
                            products: workoutP,
                            categories: aminosSlug
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Category__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Fat Loss products",
                            products: healthP,
                            categories: healthSlug
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Category__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Accessories",
                            products: accessoriesP,
                            categories: accessoriesSlug
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Categories);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7245:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Slider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Slider__WEBPACK_IMPORTED_MODULE_3__]);
_Slider__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Category = ({ title , products , categories  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-lg-2 col-md-3 col-12 my-2 text-center bg-dark product-tag-box",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "text-decoration-none text-danger cursor-p",
                    href: `/categories/${categories[0]?.slug}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "fs-5 text-uppercase ",
                            children: title
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-small text-white",
                            children: "View All Products"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-lg-10 col-md-9 col-12 p-0",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Slider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    medium: "2",
                    products: products
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3007:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Companies = ({ categories  })=>{
    const brands = [];
    categories?.map((cat)=>{
        if (cat.slug == "brands") {
            brands.push(cat.children);
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container-fluid",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-center bg-dark my-4 py-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-uppercase text-white fs-6 ",
                            children: "Brands we deals with"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-uppercase fs-2 text-danger fw-bold",
                            children: "Shop with Popular Brands"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row mb-4 justify-content-center align-items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                        navigation: true,
                        grabCursor: true,
                        modules: [
                            swiper__WEBPACK_IMPORTED_MODULE_3__.Navigation
                        ],
                        className: "mySwiper px-3 py-3",
                        style: {
                            height: "230px"
                        },
                        breakpoints: {
                            0: {
                                slidesPerView: 1,
                                spaceBetween: 30
                            },
                            480: {
                                slidesPerView: 2,
                                spaceBetween: 30
                            },
                            768: {
                                slidesPerView: 3,
                                spaceBetween: 40
                            },
                            1024: {
                                slidesPerView: 4,
                                spaceBetween: 40
                            }
                        },
                        children: brands[0]?.map((cat)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                                className: "d-flex justify-content-center align-items-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    href: `/categories/${cat.slug}`,
                                    className: "text-decoration-none text-dark",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "card border-0 rounded-0 my-4",
                                        style: {
                                            width: "15rem"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: cat.assets[0].url,
                                            className: "card-img-top comapny-image mx-auto my-auto",
                                            alt: "brand"
                                        })
                                    })
                                })
                            }, cat.id);
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Companies);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1718:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);



const Delievery = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "container-fluid bg-danger",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "row align-items-center justify-content-center text-center fw-bolder",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-lg-3 col-md-6 col-sm-12",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-white ps-2 fs-3 fw-bold",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsCreditCard2Front, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-white ps-2 text-small text-uppercase align-self-center",
                            children: "Low Price Guaranteed"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-lg-3 col-md-6 col-sm-12",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-white ps-2 fs-3 fw-bold",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsShieldCheck, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-white ps-2 text-small text-uppercase align-self-center",
                            children: "100% Authentic Products"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-lg-3 col-md-6 col-sm-12",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-white ps-2 fs-2 fw-bold",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsTruck, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-white ps-2 text-small text-uppercase align-self-center",
                            children: "Free Delievery all over pakistan"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-lg-3 col-md-6 col-sm-12",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-white ps-2 fs-4 fw-bold",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsTelephone, {})
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "text-white ps-2 text-small text-uppercase align-self-center",
                            children: [
                                "Ask any query:",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-black ps-1",
                                    children: "+923272026242"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Delievery);


/***/ }),

/***/ 1877:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Slider__WEBPACK_IMPORTED_MODULE_2__]);
_Slider__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const NewsProducts = ({ products , discount  })=>{
    const offerP = [];
    products.map((product)=>{
        if (product.categories[0].slug == "offers") {
            offerP.push(product);
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container-fluid text-center mb-4 p-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-center bg-dark mb-4 py-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-uppercase text-white fs-6 ",
                            children: "Shop with best dicsount offers"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-uppercase fs-2 text-danger fw-bold",
                            children: "Latest Offers"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Slider__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                medium: "3",
                products: offerP,
                discount: discount
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewsProducts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6078:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Slider__WEBPACK_IMPORTED_MODULE_2__]);
_Slider__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Stacks = ({ products  })=>{
    const stackP = [];
    products.map((product)=>{
        if (product.categories[0]?.slug == "stacks") {
            stackP.push(product);
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container-fluid bg-dark",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row justify-content-center align-itmes-center",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-center bg-dark my-4 py-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-uppercase text-white fs-6 ",
                                children: "Get discounted stacks"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-uppercase fs-2 text-danger fw-bold",
                                children: "stacks available"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Slider__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                medium: "2",
                products: stackP
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stacks);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Navbar_Navigation)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./assets/xtrack.png
var xtrack = __webpack_require__(4628);
// EXTERNAL MODULE: ./assets/track-2.png
var track_2 = __webpack_require__(5253);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
;// CONCATENATED MODULE: ./components/Navbar/OffCanvas.js







const OffCanvas = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "btn border-0 pt-2 text-white fs-5",
                type: "button",
                "data-bs-toggle": "offcanvas",
                "data-bs-target": "#offcanvasRight",
                "aria-controls": "offcanvasRight",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineMenu, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "offcanvas offcanvas-start bg-black",
                style: {
                    width: "300px"
                },
                tabIndex: -1,
                id: "offcanvasRight",
                "aria-labelledby": "offcanvasRightLabel",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "offcanvas-header",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col p-0 align-self-center ms-lg-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: xtrack/* default */.Z,
                                            alt: "logo",
                                            className: "img-fluid logo-x",
                                            height: 45,
                                            width: 45
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: track_2/* default */.Z,
                                            alt: "logo",
                                            className: "img-fluid logo-t",
                                            height: 45,
                                            width: 140
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "button",
                                className: "btn border-0 fs-5 text-danger",
                                "data-bs-dismiss": "offcanvas",
                                "aria-label": "Close",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineCloseCircle, {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "offcanvas-body text-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "navbar-nav text-uppercase text-small text-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item",
                                    "data-bs-dismiss": "offcanvas",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "nav-link active",
                                        "aria-current": "page",
                                        href: "/",
                                        children: "Home"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item pt-2",
                                    "data-bs-dismiss": "offcanvas",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "nav-link border-top border-danger",
                                        href: "/connect",
                                        children: "Connect with us"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "nav-item pt-2",
                                    "data-bs-dismiss": "offcanvas",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "nav-link border-top border-danger",
                                        href: "/blog",
                                        children: "Blogs"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "nav-item",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "nav-link border-bottom border-danger",
                                            children: "Categories"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "fs-5",
                                            children: "⌄"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "offcanvas-list text-center p-0 pt-2 pb-3",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "py-1",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "text-decoration-none text-white",
                                                            children: [
                                                                "Supplements",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "fs-5 ps-2",
                                                                    children: "⌄"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: "offcanvas-list text-start p-0 ps-3 py-2",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/proteins",
                                                                        children: "Proteins"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/weight-gainers",
                                                                        children: "Weight gainers"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/fat-loss-products",
                                                                        children: "fat loss products"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/pre-workouts",
                                                                        children: "Pre-workout"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/bcaa-eaa",
                                                                        children: "BCAA & EAA"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/creatine",
                                                                        children: "Creatine"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    className: "py-1 text-center",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                            className: "text-decoration-none text-white",
                                                                            children: [
                                                                                "General Health",
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "fs-5 ps-2",
                                                                                    children: "⌄"
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                            className: "offcanvas-list text-start p-0 ps-3 py-2",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    "data-bs-dismiss": "offcanvas",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        className: "nav-link py-2",
                                                                                        href: "/categories/testosterone-boosters",
                                                                                        children: "testosterone boosters"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    "data-bs-dismiss": "offcanvas",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        className: "nav-link py-2",
                                                                                        href: "/categories/fish-oil",
                                                                                        children: "fish oil"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    "data-bs-dismiss": "offcanvas",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        className: "nav-link py-2",
                                                                                        href: "/categories/zma",
                                                                                        children: "ZMA"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    "data-bs-dismiss": "offcanvas",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        className: "nav-link py-2",
                                                                                        href: "/categories/multivitamins",
                                                                                        children: "multivitamins"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "py-2",
                                                    "data-bs-dismiss": "offcanvas",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/categories/accessories",
                                                        className: "text-decoration-none text-white",
                                                        children: "Accessories"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "py-1",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "text-decoration-none text-white",
                                                            children: [
                                                                "Gym Wear",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "fs-5 ps-2",
                                                                    children: "⌄"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: "offcanvas-list text-start p-0 ps-3 py-2",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/bottoms",
                                                                        children: "Bottoms"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/tops",
                                                                        children: "Tops"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/tank-tops",
                                                                        children: "Tank Tops"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/shorts",
                                                                        children: "Shorts"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/yoga-pants",
                                                                        children: "Yoga Pants"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    "data-bs-dismiss": "offcanvas",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        className: "nav-link py-2",
                                                                        href: "/categories/track-suits",
                                                                        children: "Track Suits"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Navbar_OffCanvas = (OffCanvas);

// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
;// CONCATENATED MODULE: ./components/Navbar/Search.js




const Search = ({ products  })=>{
    const [search, setSearch] = (0,external_react_.useState)(false);
    const [query, setQuery] = (0,external_react_.useState)("");
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "col",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    href: "#search_box",
                    className: "btn border-0 text-white fs-6",
                    onClick: ()=>setSearch(!search),
                    children: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiSearch, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    className: `${search && "active"} ${"search_box , bg-white , rounded-3"}`,
                    id: "search_box",
                    action: "/search/",
                    style: {
                        maxHeight: "480px",
                        overflowY: "scroll"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            name: "search",
                            className: "rounded-pill",
                            placeholder: "Search...",
                            type: "text",
                            onChange: (c)=>setQuery(c.target.value)
                        }),
                        query == "" ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row py-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-12 text-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-small text-secondary",
                                    children: "Search products"
                                })
                            })
                        }) : products.data.filter((product)=>product.name.toLowerCase().includes(query.toLowerCase())).map((product)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `/products/${product.id}`,
                                className: "text-decoration-none",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "row py-3",
                                    onClick: ()=>setSearch(!search),
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-3 ms-sm-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: product.image.url,
                                                alt: "product-image",
                                                width: 50
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-8",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-secondary text-small text-black",
                                                children: product.name
                                            })
                                        })
                                    ]
                                })
                            }, product.id))
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Navbar_Search = (Search);

// EXTERNAL MODULE: ./context/StateContext.js
var StateContext = __webpack_require__(3233);
;// CONCATENATED MODULE: ./components/Navbar/User.js





const User = ()=>{
    let user;
    const context = (0,external_react_.useContext)(StateContext/* default */.Z);
    context.user ? user = context.user : null;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "col dropdown user-dropdown justify-content-center align-items-center p-0",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "dropdown-toggle text-white fs-6",
                    id: "navbarDropdown",
                    role: "button",
                    "data-bs-toggle": "dropdown",
                    "aria-expanded": "false",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiUser, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "dropdown-menu border-0 rounded-0 bg-dark",
                    "aria-labelledby": "navbarDropdown",
                    children: context.auth.currentUser?.email ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "dropdown-item text-small text-white py-3",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "fs-6 text-white",
                                            children: [
                                                "Welcome ",
                                                context.auth.currentUser?.displayName
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        "Logged in with",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-small text-white",
                                            children: context.auth.currentUser?.email
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/user/dashboard",
                                    className: "text-decoration-none",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "dropdown-item text-small text-white",
                                        children: "Head to Dashboard"
                                    })
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/user/login",
                                    className: "text-decoration-none",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "dropdown-item text-small text-white",
                                        href: "#",
                                        children: "Login"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/user/registration",
                                    className: "text-decoration-none",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "dropdown-item text-small text-white",
                                        href: "/",
                                        children: "Register"
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const Navbar_User = (User);

// EXTERNAL MODULE: ./context/CartContext.js
var CartContext = __webpack_require__(4426);
;// CONCATENATED MODULE: ./components/Navbar/Cart/Cart.js





const Cart = ()=>{
    const context = (0,external_react_.useContext)(CartContext/* default */.Z);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "col justify-content-center align-items-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/cart",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    type: "button",
                    className: "btn border-0 position-relative text-white",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiCart, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "position-absolute top-50 start-100 translate-middle badge rounded-pill bg-light text-black",
                            style: {
                                fontSize: "10px"
                            },
                            children: context.cart.total_items > 0 ? context.cart.total_items : 0
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const Cart_Cart = (Cart);

// EXTERNAL MODULE: ./lib/client.js
var client = __webpack_require__(5018);
;// CONCATENATED MODULE: ./components/Navbar/Navigation.js









const Navigation = ({ products  })=>{
    const context = (0,external_react_.useContext)(StateContext/* default */.Z);
    const title = context.title[0];
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container-fluid bg-dark fixed-top",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-1 d-lg-none p-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Navbar_OffCanvas, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-5 d-none d-lg-block d-md-none ps-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                className: "navbar navbar-expand-lg navbar-light",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "container-fluid",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "navbar-nav text-uppercase text-small",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    className: "nav-link active text-white",
                                                    "aria-current": "page",
                                                    href: "/",
                                                    children: "Home"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                className: "nav-item ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "nav-link dropdown-toggle active text-white position-relative cursor-p",
                                                        "aria-current": "page",
                                                        "data-bs-toggle": "dropdown",
                                                        "aria-expanded": "false",
                                                        children: "All Categories"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                        className: "dropdown-menu position-absolute ms-5 shadow",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                className: "supplement",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                        className: "dropdown-item text-small py-3",
                                                                        children: [
                                                                            "Supplements",
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                className: "ps-2 fs-6",
                                                                                children: "›"
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "nest-dropdown position-absolute bg-white rounded shadow",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                            className: "nest-list text-small p-0 py-2",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/proteins",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Proteins"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/weight-gainers",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Weight gainers"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                                    className: "health",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                                            className: "dropdown-item text-small py-3",
                                                                                            children: [
                                                                                                "General Health",
                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                                    className: "ps-1 fs-6",
                                                                                                    children: "›"
                                                                                                })
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                            className: "nest-dropdownet bg-white rounded shadow",
                                                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                                                className: "nest-list text-small p-0 py-2",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                                        className: "p-3",
                                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                                            href: "/categories/testosterone-boosters",
                                                                                                            className: "text-dark text-decoration-none",
                                                                                                            children: "testosterone boosters"
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                                        className: "p-3",
                                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                                            href: "/categories/fish-oil",
                                                                                                            className: "text-dark text-decoration-none",
                                                                                                            children: "Fish Oil"
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                                        className: "p-3",
                                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                                            href: "/categories/zma",
                                                                                                            className: "text-dark text-decoration-none",
                                                                                                            children: "ZMA"
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                                        className: "p-3",
                                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                                            href: "/categories/multivitamins",
                                                                                                            className: "text-dark text-decoration-none",
                                                                                                            children: "multivitamins"
                                                                                                        })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/fat-loss-products",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Fat loss products"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/pre-workouts",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Pre-workout"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/bcaa-eaa",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "BCAA & EAA"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/creatine",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Creatine"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "dropdown-item text-small py-3",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "/categories/accessories",
                                                                        className: "text-dark text-decoration-none",
                                                                        children: "Accessories"
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                className: "supplement",
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                        className: "dropdown-item text-small py-3",
                                                                        children: [
                                                                            "Gym Wear",
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                className: "ps-4 fs-6",
                                                                                children: "›"
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "nest-dropdown position-absolute bg-white rounded shadow",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                            className: "nest-list text-small p-0 py-2",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/bottoms",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Bottoms"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/tops",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Tops"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/tank-tops",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Tank Tops"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/shorts",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Shorts"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/yoga-pants",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Yoga Pants"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    className: "p-3",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "/categories/track-suits",
                                                                                        className: "text-dark text-decoration-none",
                                                                                        children: "Track Suits"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item ps-3",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    className: "nav-link active text-small text-white",
                                                    href: "/connect",
                                                    children: "Connect"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item ps-3",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    className: "nav-link active text-small text-white",
                                                    href: "/blog",
                                                    children: "Blogs"
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col p-0 align-self-center ms-lg-3 ms-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: title ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: (0,client/* urlFor */.u)(title?.logo),
                                alt: "logo",
                                className: "",
                                height: "60px"
                            }) : null
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "nav col justify-content-end align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item px-lg-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "nav-link p-0",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Navbar_Search, {
                                        products: products
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item px-lg-2 user-dash",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "nav-link p-0",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Navbar_User, {})
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item px-lg-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "nav-link p-0",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Cart_Cart, {})
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Navbar_Navigation = (Navigation);


/***/ }),

/***/ 8993:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$_": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_7__.Z),
/* harmony export */   "Bf": () => (/* reexport safe */ _Home_Delievery__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "OR": () => (/* reexport safe */ _Home_Companies__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "Rj": () => (/* reexport safe */ _Home_Categories__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "W_": () => (/* reexport safe */ _Navbar_Navigation__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "gO": () => (/* reexport safe */ _Home_Offers_Stacks__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "lr": () => (/* reexport safe */ _Home_Carousel__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "uG": () => (/* reexport safe */ _Home_Offers_OfferProducts__WEBPACK_IMPORTED_MODULE_4__.Z)
/* harmony export */ });
/* harmony import */ var _Navbar_Navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3415);
/* harmony import */ var _Home_Carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1891);
/* harmony import */ var _Home_Delievery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1718);
/* harmony import */ var _Home_Offers_Stacks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6078);
/* harmony import */ var _Home_Offers_OfferProducts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1877);
/* harmony import */ var _Home_Categories__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9111);
/* harmony import */ var _Home_Companies__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3007);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(723);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Home_Carousel__WEBPACK_IMPORTED_MODULE_1__, _Home_Offers_Stacks__WEBPACK_IMPORTED_MODULE_3__, _Home_Offers_OfferProducts__WEBPACK_IMPORTED_MODULE_4__, _Home_Categories__WEBPACK_IMPORTED_MODULE_5__, _Home_Companies__WEBPACK_IMPORTED_MODULE_6__]);
([_Home_Carousel__WEBPACK_IMPORTED_MODULE_1__, _Home_Offers_Stacks__WEBPACK_IMPORTED_MODULE_3__, _Home_Offers_OfferProducts__WEBPACK_IMPORTED_MODULE_4__, _Home_Categories__WEBPACK_IMPORTED_MODULE_5__, _Home_Companies__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// Navbar

// Home






// Footer


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;