(() => {
var exports = {};
exports.id = 304;
exports.ids = [304];
exports.modules = {

/***/ 2881:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports app, database */
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3745);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1492);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__]);
([firebase_app__WEBPACK_IMPORTED_MODULE_0__, firebase_firestore__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// Import the functions you need from the SDKs you need


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBZgQM3X9VAmChij97i5sXUd4-T55_qeBc",
    authDomain: "xtrackpk-1e415.firebaseapp.com",
    projectId: "xtrackpk-1e415",
    storageBucket: "xtrackpk-1e415.appspot.com",
    messagingSenderId: "418242878234",
    appId: "1:418242878234:web:bd91272951b11562cd6aa3",
    measurementId: "G-HG7LQF2SRN"
};
// Initialize Firebase
const app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.initializeApp)(firebaseConfig);
const database = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getFirestore)(app);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9605:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_commerce__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5410);
/* harmony import */ var _lib_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5018);
/* harmony import */ var _context_CartContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4426);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5856);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_go__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3015);
/* harmony import */ var _lib_firebase__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2881);
/* harmony import */ var firebase_database__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1208);
/* harmony import */ var _context_StateContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3233);
/* harmony import */ var _components_Slider__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5612);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3877);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1492);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_8__, _lib_firebase__WEBPACK_IMPORTED_MODULE_9__, firebase_database__WEBPACK_IMPORTED_MODULE_10__, _components_Slider__WEBPACK_IMPORTED_MODULE_12__, swiper__WEBPACK_IMPORTED_MODULE_16__, firebase_firestore__WEBPACK_IMPORTED_MODULE_17__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_8__, _lib_firebase__WEBPACK_IMPORTED_MODULE_9__, firebase_database__WEBPACK_IMPORTED_MODULE_10__, _components_Slider__WEBPACK_IMPORTED_MODULE_12__, swiper__WEBPACK_IMPORTED_MODULE_16__, firebase_firestore__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















async function getServerSideProps({ params  }) {
    const { id  } = params;
    return {
        props: {
            id
        }
    };
}
const Product = ({ id  })=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_CartContext__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z);
    const state = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_StateContext__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z);
    const [pageProduct, setPageProduct] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [sizeId, setSizeId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [flavourId, setFlavourId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [size, setSize] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [flavour, setFlavour] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [reviews, setReviews] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [usage, setUsage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const productusage = [];
    const disableBtn = size == "" || flavour == "" ? "cursor-d" : null;
    const getVariantSize = (id, variantId)=>{
        setSizeId(id);
        setSize(variantId);
    };
    const getVariantFlavour = (id, variantId)=>{
        setFlavourId(id);
        setFlavour(variantId);
    };
    const [quantity, setQuantity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const increment = ()=>{
        setQuantity(quantity + 1);
    };
    const decrement = ()=>{
        if (quantity > 0) {
            setQuantity(1);
        } else {
            setQuantity(quantity - 1);
        }
    };
    const openInNewTab = (url)=>{
        window.open(url, "_blank", "noopener,noreferrer");
    };
    const starRatings = [];
    let averageReview = "";
    Object.values(reviews)?.map((review)=>{
        starRatings.push(Number(review.rating));
    });
    averageReview = starRatings.length > 0 ? starRatings.reduce((a, b)=>a + b) / starRatings.length : null;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        _lib_client__WEBPACK_IMPORTED_MODULE_3__/* .client.fetch */ .L.fetch(`*[_type == 'usage']`).then((data)=>setUsage(data)).catch(console.error);
        const fetchProduct = async ()=>{
            await _lib_commerce__WEBPACK_IMPORTED_MODULE_2__/* ["default"].products.retrieve */ .Z.products.retrieve(id).then((product)=>{
                setPageProduct(product);
                const dbRef = (0,firebase_database__WEBPACK_IMPORTED_MODULE_10__.ref)(state.database);
                (0,firebase_database__WEBPACK_IMPORTED_MODULE_10__.get)((0,firebase_database__WEBPACK_IMPORTED_MODULE_10__.child)(dbRef, `reviews/${product.name}`)).then((snapshot)=>{
                    if (snapshot.exists()) {
                        setReviews(snapshot.val());
                    } else {
                        console.log("No data available");
                    }
                }).catch((error)=>{
                    console.error(error);
                });
            });
        };
        fetchProduct();
    }, []);
    usage?.map((useg)=>useg.name.toUpperCase() == pageProduct.name?.toUpperCase() ? productusage.push(useg) : null);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: pageProduct.length !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container-fluid product-box",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-6 col-12 d-flex justify-content-center align-items-center ",
                                children: pageProduct?.assets?.length > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_8__.Swiper, {
                                        navigation: true,
                                        modules: [
                                            swiper__WEBPACK_IMPORTED_MODULE_16__.Navigation
                                        ],
                                        className: "mySwiper swiper-product",
                                        slidesPerView: 1,
                                        children: pageProduct?.assets?.map((asset)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_8__.SwiperSlide, {
                                                    className: "swiper-slide-product",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: asset.url,
                                                        alt: asset.name,
                                                        className: "swipre-product-img"
                                                    })
                                                }, asset.id)
                                            }))
                                    })
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: pageProduct?.assets[0]?.url,
                                    alt: pageProduct.name,
                                    className: "cursor-p",
                                    style: {
                                        height: "350px"
                                    },
                                    onClick: ()=>openInNewTab(pageProduct.assets[0]?.url)
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-lg-6 col-12 d-flex flex-column pt-4 ps-lg-2 ps-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row text-small",
                                        children: pageProduct.inventory.available > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-danger text-uppercase col ps-2",
                                            children: "In Stock"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-danger text-uppercase col ps-2",
                                            children: "Out Of Stock"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-uppercase",
                                        children: pageProduct.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "fs-3 text-danger",
                                        children: pageProduct.variant_groups[0]?.options[0]?.id == size ? pageProduct.variant_groups[0].options[0].price.formatted_with_code : pageProduct.variant_groups[0]?.options[1]?.id == size ? pageProduct.variant_groups[0].options[1].price.formatted_with_code : pageProduct.price.formatted_with_code
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row ps-3 py-1",
                                        children: reviews ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "fs-4 ps-2",
                                                children: [
                                                    Math.ceil(averageReview),
                                                    ".0",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiFillStar, {
                                                        className: "text-warning"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "row pb-1",
                                                        style: {
                                                            marginTop: "-12px"
                                                        },
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "text-small",
                                                            children: [
                                                                "Based on ",
                                                                Object.values(reviews).length,
                                                                " reviews"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "fs-4",
                                                children: [
                                                    "0",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiFillStar, {
                                                        className: "text-warning"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "d-flex flex-column",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "py-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "ps-2",
                                                        children: pageProduct.variant_groups[0]?.name
                                                    }),
                                                    pageProduct.variant_groups ? pageProduct.variant_groups[0].options.map((option)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                onChange: (e)=>getVariantSize(pageProduct.variant_groups[0].id, e.target.value),
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                    className: "fs-6 ps-2 check-label",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            type: "radio",
                                                                            required: true,
                                                                            name: "size_option",
                                                                            value: option.id
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            children: option.name
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        });
                                                    }) : null
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col py-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "ps-2",
                                                        children: pageProduct.variant_groups[1]?.name
                                                    }),
                                                    pageProduct.variant_groups ? pageProduct.variant_groups[1]?.options.map((option)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                onChange: (e)=>getVariantFlavour(pageProduct.variant_groups[1].id, e.target.value),
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                    className: "fs-6 ps-2 check-label",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            type: "radio",
                                                                            required: true,
                                                                            name: "flavor_option",
                                                                            value: option.id
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            children: option.name
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        });
                                                    }) : null
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "p-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Quantity"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "pt-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "button",
                                                        className: "btn btn-danger btn-sm",
                                                        onClick: decrement,
                                                        children: "-"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "px-4",
                                                        children: quantity
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "button",
                                                        className: "btn btn-danger btn-sm",
                                                        onClick: increment,
                                                        children: "+"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "d-flex justify-content-center align-items-center mt-2",
                                                style: {
                                                    height: "100px"
                                                },
                                                children: pageProduct.inventory?.available > 0 ? pageProduct.variant_groups.length > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: `btn btn-danger text-uppercase ${disableBtn}`,
                                                    style: {
                                                        width: "80%"
                                                    },
                                                    onClick: ()=>context.addMultiVariantToCart(pageProduct.id, quantity, sizeId, flavourId, size, flavour),
                                                    children: "Add to cart"
                                                }) : pageProduct.variant_groups.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: `btn btn-danger text-uppercase ${disableBtn}`,
                                                    style: {
                                                        width: "80%"
                                                    },
                                                    onClick: ()=>context.addSingleVariantToCart(pageProduct.id, quantity, sizeId, size),
                                                    children: "Add to cart"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: "btn btn-danger text-uppercase",
                                                    style: {
                                                        width: "80%"
                                                    },
                                                    onClick: ()=>context.addToCart(pageProduct.id, quantity),
                                                    children: "Add to cart"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: "btn btn-danger text-uppercase",
                                                    style: {
                                                        width: "80%"
                                                    },
                                                    disabled: true,
                                                    children: "Add to cart"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container py-4",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "tab-box",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "nav nav-tabs",
                                id: "myTab",
                                role: "tablist",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "nav-link bg-dark text-white me-lg-1 me-md-1 me-0",
                                            id: "home-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#home",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "home",
                                            "aria-selected": "true",
                                            children: "Description"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "nav-link bg-dark text-white me-lg-1 me-md-1 me-0",
                                            id: "profile-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#profile",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "profile",
                                            "aria-selected": "false",
                                            children: "Usage"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-item",
                                        role: "presentation",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "nav-link bg-dark text-white",
                                            id: "contact-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#contact",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "contact",
                                            "aria-selected": "false",
                                            children: "Reviews"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "tab-content border border-2",
                                style: {
                                    minHeight: "200px"
                                },
                                id: "myTabContent",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "tab-pane fade show active p-3 description-tab",
                                        id: "home",
                                        role: "tabpanel",
                                        "aria-labelledby": "home-tab",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "pt-2",
                                            dangerouslySetInnerHTML: {
                                                __html: pageProduct.description
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "tab-pane fade p-3",
                                        id: "profile",
                                        role: "tabpanel",
                                        "aria-labelledby": "profile-tab",
                                        children: productusage.length !== 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: productusage[0].usage
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Not Prescribed"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "tab-pane fade p-3 review-tab",
                                        id: "contact",
                                        role: "tabpanel",
                                        "aria-labelledby": "contact-tab",
                                        children: [
                                            reviews ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "text-center",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "fs-6",
                                                        children: [
                                                            "Reviews for ",
                                                            pageProduct.name
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "fs-4",
                                                        children: [
                                                            Math.ceil(averageReview),
                                                            ".0",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiFillStar, {
                                                                className: "text-warning"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "row pb-1",
                                                                style: {
                                                                    marginTop: "-12px"
                                                                },
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    className: "text-small",
                                                                    children: [
                                                                        "Based on ",
                                                                        Object.values(reviews).length,
                                                                        " reviews"
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "fs-6",
                                                    children: "No reviews for this product!"
                                                })
                                            }),
                                            reviews ? Object.values(reviews)?.map((review, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "row mt-3",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-6 d-flex align-items-center",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "fs-2",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiUserCircle, {})
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    className: "text-small ps-2",
                                                                    children: [
                                                                        review.user,
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            className: "text-small text-success",
                                                                            style: {
                                                                                marginTop: "-15px"
                                                                            },
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_go__WEBPACK_IMPORTED_MODULE_7__.GoVerified, {})
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-6 text-end pe-4",
                                                            children: review.rating ? Array.from({
                                                                length: 5
                                                            }, (elem, index)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "fs-6 text-warning",
                                                                    children: review.rating >= index ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiFillStar, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiOutlineStar, {})
                                                                }, index);
                                                            }) : null
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-12 px-5",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-small",
                                                                children: review.review
                                                            })
                                                        })
                                                    ]
                                                }, index)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "container text-center py-4",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "fs-6",
                                                    children: [
                                                        "No reviews for this product!",
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: "Be the first!"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container-fluid",
                    children: pageProduct.related_products.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-uppercase py-4 ps-lg-4 ps-2 fw-bold",
                                children: "Related products"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Slider__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                medium: 2,
                                products: pageProduct.related_products
                            })
                        ]
                    }) : null
                })
            ]
        }) : null
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Product);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2996:
/***/ (() => {



/***/ }),

/***/ 6423:
/***/ ((module) => {

"use strict";
module.exports = require("@chec/commerce.js");

/***/ }),

/***/ 1097:
/***/ ((module) => {

"use strict";
module.exports = require("@sanity/client");

/***/ }),

/***/ 1791:
/***/ ((module) => {

"use strict";
module.exports = require("@sanity/image-url");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 5856:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/go");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3745:
/***/ ((module) => {

"use strict";
module.exports = import("firebase/app");;

/***/ }),

/***/ 1208:
/***/ ((module) => {

"use strict";
module.exports = import("firebase/database");;

/***/ }),

/***/ 1492:
/***/ ((module) => {

"use strict";
module.exports = import("firebase/firestore");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,18], () => (__webpack_exec__(9605)));
module.exports = __webpack_exports__;

})();