import { createContext } from 'react'

const CartStateContext = createContext()

export default CartStateContext;